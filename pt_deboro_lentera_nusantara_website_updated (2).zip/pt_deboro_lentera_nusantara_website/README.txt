PT DEBORO LENTERA NUSANTARA — WEBSITE COMPANY PROFILE

Buka index.html di browser untuk melihat website.
Konten: profil perusahaan, layanan ART, caregiver, perawat lansia (PHC), baby sitter/nanny, sopir pribadi, visi-misi, kontak, jam operasional.

Profil legal: Akta Pendirian No. 02, Notaris Devi Yanti, S.H., M.Kn.
Alamat: Perumahan Permata Zanitha Blok A No. 3, RT/RW 021/012, Kel. Bunibakti, Kec. Babelan, Kab. Bekasi, Jawa Barat 17610
Telepon/WhatsApp: 0823-6732-2284 / 0821-1270-9847
Email: deborolenteranusantara@gmail.com
Jam: Senin–Sabtu, 08.00–17.00 WIB

Formulir kontak membuka aplikasi email pengguna (mailto); bukan pengiriman langsung melalui server.
Periksa kembali informasi perusahaan sebelum website dipublikasikan.
